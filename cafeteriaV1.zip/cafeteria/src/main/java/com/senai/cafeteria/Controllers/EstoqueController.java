package com.senai.cafeteria.Controllers;

import com.senai.cafeteria.Dtos.*;
import com.senai.cafeteria.Models.EstoqueModel;
import com.senai.cafeteria.Services.EstoqueService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class EstoqueController {
    
    @Autowired
    private EstoqueService servicoEstoque;
    
    @PostMapping
    public ResponseEntity <MensagemDto> cadastrarEstoque (@Valid @RequestBody EstoqueModel a) {
        
    }
    
    @PutMapping
    public ResponseEntity <MensagemDto> atualizarEstoque(@Valid @RequestBody EstoqueModel a) {
        
    }
    
    @GetMapping("/estoque")
    public ResponseEntity <EstoqueDto> obterItensEstocados (@Valid @RequestBody EstoqueModel a) {
        
    }
    
    @GetMapping("/esgotado")
    public ResponseEntity <EstoqueDto> obterItensEsgotados (@Valid @RequestBody EstoqueModel a) {
        
    }
}
