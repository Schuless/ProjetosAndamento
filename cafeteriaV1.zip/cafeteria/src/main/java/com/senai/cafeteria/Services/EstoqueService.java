package com.senai.cafeteria.Services;

import org.springframework.stereotype.Service;

@Service

public class EstoqueService {
    
}
