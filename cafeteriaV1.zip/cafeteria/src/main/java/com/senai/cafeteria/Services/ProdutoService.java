package com.senai.cafeteria.Services;

import com.senai.cafeteria.Dtos.*;
import org.springframework.stereotype.Service;

@Service

public class ProdutoService {

    public boolean cadastrarProduto(ProdutoDto dados) {

    }
    
    public boolean atualizarProduto(ProdutoDto dados) {

    }
}
