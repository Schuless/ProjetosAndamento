package com.senai.cafeteria.Controllers;

import com.senai.cafeteria.Dtos.*;
import com.senai.cafeteria.Models.ProdutoModel;
import com.senai.cafeteria.Services.ProdutoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/produto")
public class ProdutoController {

    @Autowired
    private ProdutoService servicoProduto;

    @PostMapping
    public ResponseEntity<MensagemDto> cadastrarProdutos(@Valid @RequestBody ProdutoModel dados) {
        boolean sucesso = servicoProduto.cadastrarProduto(dados);
        MensagemDto resposta = new MensagemDto();

        if (sucesso) {
            resposta.setMensagem("Produto cadastrado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao cadastrar o produto!");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
        }
    }

    @PutMapping
    public ResponseEntity<MensagemDto> atualizarProdutos(@Valid @RequestBody ProdutoModel dados) {
        boolean sucesso = servicoProduto.atualizarProduto(dados);
        MensagemDto resposta = new MensagemDto();

        if (sucesso) {
            resposta.setMensagem("Produto atualizado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao atualizar o produto!");
            return ResponseEntity.ok(resposta);
        }
    }

    @GetMapping("/bebidas")
    public ResponseEntity<ProdutoDto> obterBebidas(@Valid @RequestBody ProdutoModel dados) {

    }

    @GetMapping("/alimentos")
    public ResponseEntity<ProdutoDto> obterAlimentos(@Valid @RequestBody ProdutoModel dados) {

    }
}
