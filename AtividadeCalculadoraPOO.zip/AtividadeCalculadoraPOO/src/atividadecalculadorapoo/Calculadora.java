
import javax.swing.*;

public class Calculadora {

    public static void main(String[] args) {
        int resultado;
        String[] opcoes = {"soma", "multiplicação", "subtração", "divisão"};
        String escolha = (String) JOptionPane.showInputDialog(
                null,
                "Escolha uma operação:",
                "Calculadora",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]
        );
        //Pede ao usuario dois numeros inteiros
        int numero1 = Integer.parseInt(JOptionPane.showInputDialog("Digite o primeiro número:"));
        int numero2 = Integer.parseInt(JOptionPane.showInputDialog("Digite o segundo número:"));

        Adicao adicao = new Adicao(numero1, numero2);
        Multiplicacao multipli = new Multiplicacao(numero1, numero2);
        Subtracao subtrai = new Subtracao(numero1, numero2);
        Divisao dividi = new Divisao(numero1, numero2);
        
        //Busca o metodo desejado, transforma e exibe a variavel resultado nele
        if (escolha == "soma") {
            resultado = adicao.somar();
        } else if (escolha == "multiplicação") {
            resultado = multipli.multiplicar();
        } else if (escolha == "subtração") {
            resultado = subtrai.subtrair();
        } else {
            escolha = "divisão";
            resultado = dividi.dividir();
        }

        JOptionPane.showMessageDialog(null, "A "+ escolha +" dos dois números é: " + resultado);
    }
}

//classe que realiza as operações de adição
class Adicao {

    private int numero1;
    private int numero2;

    // Construtor que recebe os dois números
    public Adicao(int numero1, int numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    // Getters e Setters
    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {
        this.numero2 = numero2;
    }

    // Método que retorna a soma dos dois números
    public int somar() {
        return this.numero1 + this.numero2;
    }
}

class Multiplicacao {

    private int numero1;
    private int numero2;

    // Construtor que recebe os dois números
    public Multiplicacao(int numero1, int numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    // Getters e Setters
    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {
        this.numero2 = numero2;
    }

    // Método que retorna a multiplicacao dos dois números
    public int multiplicar() {
        return this.numero1 * this.numero2;
    }
}
class Subtracao {

    private int numero1;
    private int numero2;

    // Construtor que recebe os dois números
    public Subtracao(int numero1, int numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    // Getters e Setters
    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {
        this.numero2 = numero2;
    }

    // Método que retorna a subtracao dos dois números
    public int subtrair() {
        return this.numero1 - this.numero2;
    }
}
class Divisao {

    private int numero1;
    private int numero2;

    // Construtor que recebe os dois números
    public Divisao(int numero1, int numero2) {
        this.numero1 = numero1;
        this.numero2 = numero2;
    }

    // Getters e Setters
    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {
        this.numero2 = numero2;
    }

    // Método que retorna a divisao dos dois números
    public int dividir() {
        return this.numero1 / this.numero2;
    }
}
