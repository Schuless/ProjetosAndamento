package atividadecalculadorapoo;

import javax.swing.JOptionPane;

public class AtividadeCalculadoraPOO {

    private int numero1;
    private int numero2;
    
    public AtividadeCalculadoraPOO() {
    }
    
    public int adicao(int num1, int num2) {
    this.numero1 = num1;
    this.numero2 = num2;
    int soma = numero1 + numero2;
    return soma;
    }

    public int getNumero1() {
        return numero1;
    }

    public void setNumero1(int numero1) {
        this.numero1 = numero1;
    }

    public int getNumero2() {
        return numero2;
    }

    public void setNumero2(int numero2) {
        this.numero2 = numero2;
    }
    
    public static void main(String[] args) {
        int nume1 = Integer.parseInt(JOptionPane.showInputDialog("Defina o numero 1:"));
        int num21 = Integer.parseInt(JOptionPane.showInputDialog("Defina o numero 2:"));
        JOptionPane.showMessageDialog(null, "A soma dos dois numeros é " + soma);
    }
    
}
