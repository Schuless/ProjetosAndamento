package com.senai.exercicio3.controllers;

import com.senai.exercicio3.dtos.*;
import com.senai.exercicio3.services.CampeonatoServices;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/campeonato")
public class CampeonatoController {
    //{
    //"nomeCampeonato" : "ESL Rio",
    //"premiacaoCampeonato" : "50,000" ,
    //"limiteTimes" : "16",
    //"codigoCampeonato": "eslRio"
    //}

    @Autowired
    CampeonatoServices servico;

    @PostMapping
    public ResponseEntity<MensagemDto> cadastrarCampeonato(@RequestBody EntradaCampeonatoDto dados) {
        //controla a validacao do boolean do service
        boolean sucesso = servico.cadastrarCampeonato(dados);
        //cria uma variavel resposta do tipo mensagem para realizar a impressao de uma resposta de acordo com o boolean
        MensagemDto resposta = new MensagemDto();
        //verifica se a expressao é verdadeira ou falsa e imprime a mensagem ao usario
        if (sucesso) {
            resposta.setMensagem("Cadastro realizado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao realizar cadastro!");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }
    }

    @PutMapping
    public ResponseEntity<MensagemDto> atualizarCampeonato(@RequestBody EntradaCampeonatoDto dados) {
        //controla a validacao do boolean do service
        boolean sucesso = servico.cadastrarCampeonato(dados);
        MensagemDto resposta = new MensagemDto();
        //verifica se a expressao é verdadeira ou falsa e imprime a mensagem ao usario
        if (sucesso) {
            resposta.setMensagem("Campeonato atualizado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao atualizar campeonato!");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }
    }

    @GetMapping
    public ArrayList<EntradaCampeonatoDto> obterCampeonato() {
        //busca os itens presentes na lista de campeonatos registrados na classe service
        ArrayList<EntradaCampeonatoDto> campeonatos = servico.obterListaCampeonatos();
        //imprime os itens da lista
        return campeonatos;
    }
}
