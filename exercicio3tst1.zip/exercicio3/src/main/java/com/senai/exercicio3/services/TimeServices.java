package com.senai.exercicio3.services;

import com.senai.exercicio3.dtos.*;
import com.senai.exercicio3.models.*;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service
public class TimeServices {

    ArrayList<TimeModel> listaTimes = new ArrayList<>();

    public boolean cadastrarTime(EntradaTimeDto dados) {
        //variavel responsavel por verificar se o campeonato ja esta cadastrado ou nao
        TimeModel equipe = new TimeModel();
        for (TimeModel equipeItem : listaTimes) {
            if (equipeItem.getCodigoEquipe().equals(dados.getCodigoEquipe())) {
                return false;
            }
        }
        //set dados da equipe a um obj
        equipe.setNomeTime(dados.getNomeTime());
        equipe.setNacionalidade(dados.getNacionalidade());
        equipe.setQuantidadeJogadores(dados.getQuantidadeJogadores());
        equipe.setCodigoEquipe(dados.getCodigoEquipe());

        //adiciona o obj equipe na lista de times
        listaTimes.add(equipe);

        return true;
    }

    public boolean atualizarTime(EntradaTimeDto dados) {
        for (TimeModel equipeItem : listaTimes) {
            // Verifica se o código do time atual corresponde ao código do time da requisição
            if (equipeItem.getCodigoEquipe().equals(dados.getCodigoEquipe())) {
                // Atualiza os dados do time
                equipeItem.setNomeTime(dados.getNomeTime());
                equipeItem.setNacionalidade(dados.getNacionalidade());
                equipeItem.setQuantidadeJogadores(dados.getQuantidadeJogadores());
                return true; // Atualização bem-sucedida
            }
        }
        return false; // Código do equipe não encontrado
    }

    public ArrayList<EntradaTimeDto> obterListaTimes() {

        ArrayList<EntradaTimeDto> listaEquipes = new ArrayList<>();

        for (TimeModel equipeItem : listaTimes) {
            EntradaTimeDto lista = new EntradaTimeDto();
            lista.setNomeTime(equipeItem.getNomeTime());
            lista.setNacionalidade(equipeItem.getNacionalidade());
            lista.setQuantidadeJogadores(equipeItem.getQuantidadeJogadores());
            lista.setCodigoEquipe(equipeItem.getCodigoEquipe());
            listaEquipes.add(lista);
        }
        return listaEquipes;
    }
}
