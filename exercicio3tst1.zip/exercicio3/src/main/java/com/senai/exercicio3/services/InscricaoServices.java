package com.senai.exercicio3.services;

import com.senai.exercicio3.dtos.InscricaoDto;
import com.senai.exercicio3.models.InscricaoModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service
public class InscricaoServices {

    ArrayList<InscricaoModel> listaTimesInscritos = new ArrayList<>();

    public boolean inscreverTime(InscricaoDto dados) {
        InscricaoModel equipe = new InscricaoModel();
        for (InscricaoModel equipeItem : listaTimesInscritos) {
            if ((equipeItem.getCodigoCampeonato().equals(dados.getCodigoCampeonato())) && (equipeItem.getNomeTime().equals(dados.getNomeTime()))) {
                return false;
            }
        }
        //set dados da equipe a um obj
        
        equipe.setCodigoCampeonato(dados.getCodigoCampeonato());
        equipe.setLimiteTimes(dados.getLimiteTimes());
        equipe.setNomeCampeonato(dados.getNomeCampeonato());
        equipe.setPremiacaoCampeonato(dados.getPremiacaoCampeonato());
        equipe.setNomeTime(dados.getNomeTime());
        //adiciona o obj equipe na lista de times
        listaTimesInscritos.add(equipe);

        return true;
    }

    public ArrayList<InscricaoDto> obterListaTimesInscritos() {

        ArrayList<InscricaoDto> listaEquipes = new ArrayList<>();

        for (InscricaoModel equipeItem : listaTimesInscritos) {
            InscricaoDto lista = new InscricaoDto();

            lista.setCodigoCampeonato(equipeItem.getCodigoCampeonato());
            lista.setLimiteTimes(equipeItem.getLimiteTimes());
            lista.setNomeCampeonato(equipeItem.getNomeCampeonato());
            lista.setPremiacaoCampeonato(equipeItem.getPremiacaoCampeonato());
            lista.setNomeTime(equipeItem.getNomeTime());

            listaEquipes.add(lista);
        }
        return listaEquipes;
    }
}
