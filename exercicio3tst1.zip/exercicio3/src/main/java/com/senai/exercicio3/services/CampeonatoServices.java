package com.senai.exercicio3.services;

import com.senai.exercicio3.dtos.*;
import com.senai.exercicio3.models.CampeonatoModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service
public class CampeonatoServices {

    ArrayList<CampeonatoModel> listaCampeonatos = new ArrayList<>();

    public boolean cadastrarCampeonato(EntradaCampeonatoDto dados) {
        //variavel responsavel por verificar se o campeonato ja esta cadastrado ou nao
        CampeonatoModel campeonato = new CampeonatoModel();
        for (CampeonatoModel campeonatoItem : listaCampeonatos) {
            if (campeonatoItem.getCodigoCampeonato().equals(dados.getCodigoCampeonato())) {
                return false;
            }
        }

        campeonato.setNomeCampeonato(dados.getNomeCampeonato());
        campeonato.setPremiacaoCampeonato(dados.getPremiacaoCampeonato());
        campeonato.setLimiteTimes(dados.getLimiteTimes());
        campeonato.setCodigoCampeonato(dados.getCodigoCampeonato());

        //adiciona o obj campeonatoItem na lista de campeonatos
        listaCampeonatos.add(campeonato);

        return true;
    }

    public boolean atualizarCampeonato(EntradaCampeonatoDto dados) {

        CampeonatoModel campeonato = new CampeonatoModel();
        for (CampeonatoModel campeonatoItem : listaCampeonatos) {
            if (campeonatoItem.getCodigoCampeonato().equals(dados.getCodigoCampeonato())) {
                campeonatoItem.setNomeCampeonato(dados.getNomeCampeonato());
                campeonatoItem.setLimiteTimes(dados.getLimiteTimes());
                campeonatoItem.setPremiacaoCampeonato(dados.getPremiacaoCampeonato());
                return true; // Atualização bem-sucedida
            }
        }
        return false; // Código do campeonato não encontrado
    }

    public ArrayList<EntradaCampeonatoDto> obterListaCampeonatos() {

        ArrayList<EntradaCampeonatoDto> listaCamps = new ArrayList<>();

        for (CampeonatoModel campeonatoItem : listaCampeonatos) {
            EntradaCampeonatoDto lista = new EntradaCampeonatoDto();
            lista.setNomeCampeonato(campeonatoItem.getNomeCampeonato());
            lista.setPremiacaoCampeonato(campeonatoItem.getPremiacaoCampeonato());
            lista.setLimiteTimes(campeonatoItem.getLimiteTimes());
            lista.setCodigoCampeonato(campeonatoItem.getCodigoCampeonato());
            listaCamps.add(lista);
        }
        return listaCamps;
    }

}
