package com.senai.exercicio3.controllers;

import com.senai.exercicio3.dtos.EntradaCampeonatoDto;
import com.senai.exercicio3.dtos.EntradaTimeDto;
import com.senai.exercicio3.dtos.InscricaoDto;
import com.senai.exercicio3.dtos.MensagemDto;
import com.senai.exercicio3.services.InscricaoServices;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/inscrever")
public class InscricaoController {
    //{
    //"nomeCampeonato" : "ESL Rio",
    //"premiacaoCampeonato" : "50,000" ,
    //"limiteTimes" : "16",
    //"codigoCampeonato": "eslRio",
    //"nomeTime" : "Faze Clan"
    //}

    @Autowired
    InscricaoServices servico;

    @PostMapping()
    public ResponseEntity<MensagemDto> inscreverTime(@RequestBody InscricaoDto dados ) {
        //controla a validacao do boolean do service
        boolean sucesso = servico.inscreverTime(dados);
        //cria uma variavel resposta do tipo mensagem para realizar a impressao de uma resposta de acordo com o boolean
        MensagemDto resposta = new MensagemDto();
        //verifica se a expressao é verdadeira ou falsa e imprime a mensagem ao usario
        if (sucesso) {
            resposta.setMensagem("Equipe isncrita com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao realizar inscrição de equipe em evento!");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }
    }

    @GetMapping()
    public ArrayList<InscricaoDto> obterListaTimesInscritos() {
        //busca os times inscritos nos campeonatos existentes
        ArrayList<InscricaoDto> times = servico.obterListaTimesInscritos();
        //imprime os itens da lista
        return times;
    }
}
