package com.senai.exercicio3.models;

public class CampeonatoModel {
    private String nomeCampeonato;
    private String premiacaoCampeonato;
    private int limiteTimes;
    private String codigoCampeonato;

    public CampeonatoModel() {
    }

    public String getNomeCampeonato() {
        return nomeCampeonato;
    }

    public void setNomeCampeonato(String nomeCampeonato) {
        this.nomeCampeonato = nomeCampeonato;
    }

    public String getPremiacaoCampeonato() {
        return premiacaoCampeonato;
    }

    public void setPremiacaoCampeonato(String premiacaoCampeonato) {
        this.premiacaoCampeonato = premiacaoCampeonato;
    }

    public int getLimiteTimes() {
        return limiteTimes;
    }

    public void setLimiteTimes(int limiteTimes) {
        this.limiteTimes = limiteTimes;
    }

    public String getCodigoCampeonato() {
        return codigoCampeonato;
    }

    public void setCodigoCampeonato(String codigoCampeonato) {
        this.codigoCampeonato = codigoCampeonato;
    }
    
    
}
