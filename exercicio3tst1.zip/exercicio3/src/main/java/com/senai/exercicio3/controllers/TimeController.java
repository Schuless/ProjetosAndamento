package com.senai.exercicio3.controllers;

import com.senai.exercicio3.dtos.*;
import com.senai.exercicio3.services.TimeServices;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/time")
public class TimeController {
    
    //  {
    //  "nomeTime" : "Natus Vincere",
    //  "nacionalidade" : "Ucrania" ,
    //  "quantidadeJogadores" : "5",
    //  "codigoEquipe": "1"}
    
    @Autowired
    TimeServices servico;

    @PostMapping()
    public ResponseEntity<MensagemDto> cadastrarTime(@RequestBody EntradaTimeDto dados) {
        //controla a validacao do boolean do service
        boolean sucesso = servico.cadastrarTime(dados);
        //cria uma variavel resposta do tipo mensagem para realizar a impressao de uma resposta de acordo com o boolean
        MensagemDto resposta = new MensagemDto();
        //verifica se a expressao é verdadeira ou falsa e imprime a mensagem ao usario
        if (sucesso) {
            resposta.setMensagem("Equipe cadastrada com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao realizar cadastro de equipe!");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }
        
    }


    @PutMapping()
    public ResponseEntity<MensagemDto> atualizarTime(@RequestBody EntradaTimeDto dados) {
        //controla a validacao do boolean do service
        boolean sucesso = servico.atualizarTime(dados);
        MensagemDto resposta = new MensagemDto();
        //verifica se a expressao é verdadeira ou falsa e imprime a mensagem ao usario
        if (sucesso) {
            resposta.setMensagem("Campeonato atualizado com sucesso!");
            return ResponseEntity.ok(resposta);
        } else {
            resposta.setMensagem("Falha ao atualizar campeonato!");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(resposta);
        }
    }


    @GetMapping()
    public ArrayList<EntradaTimeDto> obterListaTimes() {
        //busca os itens presentes na lista de times registrados na classe service
        ArrayList<EntradaTimeDto> times = servico.obterListaTimes();
        //imprime os itens da lista
        return times;
    }
}
