package controladoraEconomia;


import javax.swing.JOptionPane;

public class Compras {
    public static void main(String[] args) {
        String escolha;
        float resultadoAcademia, resultadoTotal = 0;
        do {
            String[]opcoes = {"Academia", "Viagem", "Jogos", "Ifood", "Uber", "Mercado", "Outros", "Encerrar conta"};
            escolha = (String) JOptionPane.showInputDialog(
                null,
                "Escolha uma :",
                "Calculadora",
                JOptionPane.QUESTION_MESSAGE,
                null,
                opcoes,
                opcoes[0]
            );
            if (escolha == "Academia") {
                float gastosAcademia = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor gasto com sua academia esse mês:"));
                float gastosSuplementos = Integer.parseInt(JOptionPane.showInputDialog("Digite o valor gasto com suplementos nesse mês:"));    
            }
            Academia valorTotal = new Academia();
            resultadoAcademia = valorTotal.academiaTotal();
            resultadoTotal+= resultadoAcademia;
            if (escolha == "Encerrar conta") {
                JOptionPane.showMessageDialog(null, "Conta encerrada, sua divida foi de: R$" + resultadoTotal + "Academia: R$" + resultadoAcademia);
            }
        } while (escolha != "Encerrar conta");
    }
}

class Academia {
    private float valorItensAcademia;
    private float valorSuplementos;
            
    public Academia(){
     
    }
    public Academia(float valorItensAcademia, float valorSuplementos){
        this.valorItensAcademia = valorItensAcademia;
        this.valorSuplementos = valorSuplementos;
    }

    public float getValorItensAcademia() {
        return valorItensAcademia;
    }

    public void setValorItensAcademia(float valorItensAcademia) {
        this.valorItensAcademia = valorItensAcademia;
    }

    public float getValorSuplementos() {
        return valorSuplementos;
    }

    public void setValorSuplementos(float valorSuplementos) {
        this.valorSuplementos = valorSuplementos;
    }
    public float academiaTotal() {
        return this.valorItensAcademia + this.valorSuplementos;
    }
}
