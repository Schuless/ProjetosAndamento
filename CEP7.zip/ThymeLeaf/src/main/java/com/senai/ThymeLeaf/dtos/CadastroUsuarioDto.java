package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data
public class CadastroUsuarioDto {
   
    private String email;
    
    private String senha;
}
