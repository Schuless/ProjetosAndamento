package com.senai.ThymeLeaf.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.util.Date;
import lombok.Data;

@Entity
@Table (name="OPERACAO")
@Data
public class OperacaoModel {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    @Column(name = "entidade")
    private String entidade;

    @Column(name = "operacao ")
    private String operacao ;
    
    @Column(name = "data/hora")
    private Date dataHora;
    
    @Column(name = "user")
    private String user;
    
}
