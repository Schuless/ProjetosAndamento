package com.senai.ThymeLeaf.repositories;

import com.senai.ThymeLeaf.models.EstadoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EstadoRepository extends JpaRepository<EstadoModel, Long>{
    
    //--Metodo que irá forçar a classe JpaRepository<UsuarioModel, Long> 
    //--implementar o select * from Usuario where UsuarioLogin = 'admin'
    //public Optional<EstadoModel> findByCpf(String cpf);
    
   
}

