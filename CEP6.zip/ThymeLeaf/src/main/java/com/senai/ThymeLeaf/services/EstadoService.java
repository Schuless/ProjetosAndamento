package com.senai.ThymeLeaf.services;

import com.senai.ThymeLeaf.dtos.EstadoDto;
import com.senai.ThymeLeaf.models.EstadoModel;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.senai.ThymeLeaf.repositories.EstadoRepository;

@Service
public class EstadoService {

    @Autowired
    EstadoRepository repositorio;
    
       public boolean cadastrarEstado(EstadoDto dados){
             
        EstadoModel estado = new EstadoModel();
        
        estado.setCodigo(dados.getCodigo());
        estado.setNome(dados.getNome());
        estado.setSigla(dados.getSigla());
        
        
        repositorio.save(estado);
        
        return true;
        
    }
    
    public List<EstadoModel> obterListaEstados(){
        
        List<EstadoModel> lista = repositorio.findAll();
        
        return lista;
        
    }

    public EstadoDto obterEstadoPorId(Long codigo){
        
        Optional<EstadoModel> optionalEstado = repositorio.findById(codigo);
        
        EstadoDto contato = new EstadoDto();
        
        if (!optionalEstado.isPresent()){            
            contato.setCodigo(0L);
            return contato;
        }
        
        //contato.setCodigo(optionalContato.get().getCodigo());
        //contato.setEmail(optionalContato.get().getEmail());        
        
        return contato;
    }
}
