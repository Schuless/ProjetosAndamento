package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.CidadeDto;
import com.senai.ThymeLeaf.services.CidadesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/estado")
public class EstadoController {
    
    @Autowired
    private CidadesService contatoService;  
    
    @PostMapping()
    public String cadastrarContato(@ModelAttribute("estado") CidadeDto contato){
        
        boolean sucesso = contatoService.cadastrarContato(contato);
        
        if (sucesso){
            return "redirect:listaestados";
        }

        return "redirect:cadastrarestdos?erro";        
    }
}
