package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data
public class AtualizarDto {
    
    private Long codigo;
    
    private String email;
    
}
