package com.atividades.exercicio1.controller;

import com.atividades.exercicio1.dtos.*;
import com.atividades.exercicio1.services.Calcular;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/calculadora")
public class CalculadoraController {
    
    @Autowired
    Calcular calculadora;
    
    @PostMapping("/soma")
     public ResponseEntity<ResultadoDTO> adicao(@RequestBody CalculadoraDTO dados) {
        //processa a requisição
        ResultadoDTO somar = calculadora.adicao(dados);
        
        return ResponseEntity.accepted().body(somar);
    }
     
    @PostMapping("/multiplicacao")
     public ResponseEntity<ResultadoDTO> multiplica(@RequestBody CalculadoraDTO dados) {
        //processa a requisição
        ResultadoDTO multiplicacao = calculadora.multiplicacao(dados);
        
        return ResponseEntity.accepted().body(multiplicacao);
    }
     
    @PostMapping("/subtracao")
     public ResponseEntity<ResultadoDTO> divide(@RequestBody CalculadoraDTO dados) {
        //processa a requisição
        ResultadoDTO subtracao = calculadora.subtracao(dados);
        
        return ResponseEntity.accepted().body(subtracao);
    }
     
    @PostMapping("/divisao")
     public ResponseEntity<ResultadoDTO> subtrai(@RequestBody CalculadoraDTO dados) {
        //processa a requisição
        ResultadoDTO divisao = calculadora.divisao(dados);
        
        return ResponseEntity.accepted().body(divisao);
    }
     
     
    
}
