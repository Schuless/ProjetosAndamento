package com.atividades.exercicio1.dtos;

public class ResultadoDTO {

    private int soma;
    private int multiplica;
    private int divide;
    private int subtrai;

    public ResultadoDTO() {

    }

    public int getSoma() {
        return soma;
    }

    public void setSoma(int soma) {
        this.soma = soma;
    }

    public int getMultiplica() {
        return multiplica;
    }

    public void setMultiplica(int multiplica) {
        this.multiplica = multiplica;
    }

    public int getDivide() {
        return divide;
    }

    public void setDivide(int divide) {
        this.divide = divide;
    }

    public int getSubtrai() {
        return subtrai;
    }

    public void setSubtrai(int subtrai) {
        this.subtrai = subtrai;
    }
    
    
}
