package com.atividades.exercicio1.services;

import com.atividades.exercicio1.dtos.*;
import org.springframework.stereotype.Service;

@Service
public class Calcular {

    public ResultadoDTO adicao(CalculadoraDTO soma) {
        int dados = soma.getNumero1() + soma.getNumero2();
        ResultadoDTO retorno = new ResultadoDTO();
        retorno.setSoma(dados);

        return retorno;

    }
    public ResultadoDTO multiplicacao(CalculadoraDTO multiplica) {
        int dados = multiplica.getNumero1() * multiplica.getNumero2();
        ResultadoDTO retorno = new ResultadoDTO();
        retorno.setMultiplica(dados);
        
        return retorno;
        
    }
    public ResultadoDTO divisao(CalculadoraDTO divide) {
        int dados = divide.getNumero1() / divide.getNumero2();
        ResultadoDTO retorno = new ResultadoDTO();
        retorno.setDivide(dados);
        
        return retorno;
        
    }
    public ResultadoDTO subtracao(CalculadoraDTO subtrai) {
        int dados = subtrai.getNumero1() - subtrai.getNumero2();
        ResultadoDTO retorno = new ResultadoDTO();
        retorno.setSubtrai(dados);
        System.out.println("");
        
        return retorno;
        
    }

}
