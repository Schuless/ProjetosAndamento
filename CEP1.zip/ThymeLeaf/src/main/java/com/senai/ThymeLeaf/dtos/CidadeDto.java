package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data

public class CidadeDto {

    private long codigo;
    
    private String nome;
    
    private String Estado;
    
}
