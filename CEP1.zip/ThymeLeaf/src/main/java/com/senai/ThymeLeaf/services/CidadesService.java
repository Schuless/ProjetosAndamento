package com.senai.ThymeLeaf.services;

import com.senai.ThymeLeaf.dtos.CidadeDto;
import com.senai.ThymeLeaf.models.CidadeModel;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.senai.ThymeLeaf.repositories.CidadeRepository;

@Service
public class CidadesService {

    @Autowired
    CidadeRepository repositorio;
    
       public boolean cadastrarCidade(CidadeDto dados){
             
        CidadeModel cidade = new CidadeModel();

        cidade.setCodigo(dados.getCodigo());
        cidade.setNome(dados.getNome());
        cidade.setEstado(dados.getEstado());
        
        repositorio.save(cidade);
        
        return true;
        
    }
    
    public List<CidadeModel> obterListaCidades(){
        
        List<CidadeModel> lista = repositorio.findAll();
        
        return lista;
        
    }

    public CidadeDto obterCidadePorId(Long codigo){
        
        Optional<CidadeModel> optionalContato = repositorio.findById(codigo);
        
        CidadeDto contato = new CidadeDto();
        
        if (!optionalContato.isPresent()){            
            contato.setCodigo(0L);
            return contato;
        }
        
        //contato.setCodigo(optionalContato.get().getCodigo());
        //contato.setEmail(optionalContato.get().getEmail());        
        
        return contato;
    }
}
