package com.senai.ThymeLeaf.services;

import com.senai.ThymeLeaf.dtos.ContatoDto;
import com.senai.login.models.ContatoModel;
import com.senai.login.repositories.ContatoRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ContatoService {

    @Autowired
    ContatoRepository repositorio;
    
       public boolean cadastrarContato(ContatoDto dados){
             
        ContatoModel contato = new ContatoModel();

        contato.setNome(dados.getNomeContato());
        contato.setNome(dados.getNomeContato());
        contato.setEmail(dados.getEmailContato());
        contato.setEndereco(dados.getEnderecoContato());
        contato.setTelefone(dados.getTelefoneContato());
        contato.setCpf(dados.getCpfContato());
        
        repositorio.save(contato);
        
        return true;
        
    }

    public boolean atualizarContatoPorCpf(ContatoDto contato, String cpf){

       Optional<ContatoModel> optionalContato = obterContatoPorCpf(cpf);

       if (!optionalContato.isPresent()){
           return false;
       }
       
        ContatoModel contatoAtualizado = optionalContato.get();
        contatoAtualizado.setNome(contato.getNomeContato());
        contatoAtualizado.setEmail(contato.getEmailContato());
        contatoAtualizado.setEndereco(contato.getEnderecoContato());
        contatoAtualizado.setTelefone(contato.getTelefoneContato());
        
        repositorio.save(contatoAtualizado);
        
        return true;
    }    
    public boolean atualizarContatoPorId(ContatoDto contato, Long codigo){
        
       System.out.println("id:" + codigo);
        
       Optional<ContatoModel> optionalContato = repositorio.findById(codigo);

       if (!optionalContato.isPresent()){
           return false;
       }
       
        ContatoModel contatoAtualizado = optionalContato.get();
        contatoAtualizado.setNome(contato.getNomeContato());
        contatoAtualizado.setEmail(contato.getEmailContato());
        contatoAtualizado.setEndereco(contato.getEnderecoContato());
        contatoAtualizado.setTelefone(contato.getTelefoneContato());
        contatoAtualizado.setCpf(contato.getCpfContato());
        
        repositorio.save(contatoAtualizado);
        
        return true;
    }
   
    public boolean excluirContato(Long codigo){
        
        System.out.println("id:" + codigo);
        
        Optional<ContatoModel> optionalContato = repositorio.findById(codigo);
        
        if (optionalContato.isPresent()){
            repositorio.deleteById(codigo);        
            return true;
        }      
                
        return false;
    }
    
    public List<ContatoModel> obterContatos(){
        
        List<ContatoModel> lista = repositorio.findAll();
        
        return lista;
        
    }

    public Optional<ContatoModel> obterContatoPorCpf(String cpf){
        
        Optional<ContatoModel> optionalContato = repositorio.findByCpf(cpf);
     
        return optionalContato;
    }
    
    public ContatoDto obterContatoPorId(Long codigo){
        
        Optional<ContatoModel> optionalContato = repositorio.findById(codigo);
        
        ContatoDto contato = new ContatoDto();
        
        if (!optionalContato.isPresent()){            
            contato.setCodigo(0L);
            return contato;
        }
        
        contato.setCodigo(optionalContato.get().getCodigo());
        contato.setEmailContato(optionalContato.get().getEmail());        
        
        return contato;
    }
}
