package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data

public class ContatoDto {

    private long codigo;
    
    private String nomeContato;
    
    private String telefoneContato;
    
    private String emailContato;
    
    private String enderecoContato;
   
    private String cpfContato;

}
