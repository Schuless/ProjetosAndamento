package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.ContatoDto;
import com.senai.ThymeLeaf.services.ContatoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/visualizarcontato")
public class VisualizarContatoController {
    
    @Autowired
    ContatoService contatoService;
    
    @GetMapping("/{id}")
    public String exibirVisualizarContato(Model model, @PathVariable Long id){

        ContatoDto contato = contatoService.obterContatoPorId(id);
                
        model.addAttribute("contatoDto", contato);
        
        if (contato.getCodigo() > 0){
            return "visualizarcontato";
        }
        
        return "redirect:/listacontatos";
        
    }
    
}
