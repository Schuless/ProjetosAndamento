package com.senai.ThymeLeaf.dtos;

import lombok.Data;

@Data

public class ContatoDto {

    private long codigo;
    
    private String nome;
    
    private String telefone;
    
    private String email;
    
    private String endereco;
   
    private String cpf;

}
