package com.senai.ThymeLeaf.dtos;

public class AtualizarDto {
    
    private Long codigo;
    
    private String email;
    
}
