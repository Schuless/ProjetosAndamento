package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.CidadeDto;
import com.senai.ThymeLeaf.services.CidadesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cidades")
public class CidadeController {
    
    @Autowired
    private CidadesService cidadesService;  
    
    @GetMapping("/cadastrar")
    public String exibirListaCidades(Model model){
        
        CidadeDto cidadeDto = new CidadeDto();
        
        model.addAttribute("cidadeDto", cidadeDto);
        
        return "cadastrarcidade";
    }
    
    
    @PostMapping()
    public String cadastrarContato(@ModelAttribute("cidades") CidadeDto cidade){
        
        boolean sucesso = cidadesService.cadastrarCidade(cidade);
        
        if (sucesso){
            return "redirect:listacidades";
        }

        return "redirect:cadastrarcidades?erro";        
    }
}
