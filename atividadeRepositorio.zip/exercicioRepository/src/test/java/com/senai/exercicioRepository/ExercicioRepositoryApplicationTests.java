package com.senai.exercicioRepository;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioRepositoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
