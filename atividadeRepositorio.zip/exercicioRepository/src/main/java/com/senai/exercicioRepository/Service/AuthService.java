package com.senai.exercicioRepository.Service;

import com.senai.exercicioRepository.DTOs.MensagemDtos;
import com.senai.exercicioRepository.DTOs.LoginDto;
import com.senai.exercicioRepository.Model.UserModel;
import com.senai.exercicioRepository.Repositorio.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    public boolean getUserByLogin(LoginDto login) {
        Optional<UserModel> optionalUser = userRepository.findByLogin(login);

        if (optionalUser.isPresent()) {
            if (optionalUser.get().getSenha().equals(login.getSenha())) {
                return true;
            }
        }
        return false;
    }
}
