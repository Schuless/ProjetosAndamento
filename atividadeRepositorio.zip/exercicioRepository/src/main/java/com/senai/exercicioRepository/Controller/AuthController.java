package com.senai.exercicioRepository.Controller;

import com.senai.exercicioRepository.DTOs.*;
import com.senai.exercicioRepository.Model.UserModel;
import com.senai.exercicioRepository.Service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/usuario")
public class AuthController {

    @Autowired
    AuthService servico;

    //submeter dados usuario
    @PostMapping
    public ResponseEntity<MensagemDtos> cadastrarUsuario(@Valid @RequestBody UserModel dados) {

        boolean sucesso = servico.getUserByLogin(dados);
        MensagemDtos resposta = new MensagemDtos();
        
        if (sucesso) {
            resposta.setMensagemdto("Login realizado com sucesso!");
        } else {
            resposta.setMensagemdto("Falha ao realizar o login!");
        }
        return ResponseEntity.ok(resposta);

    }

    //obter dados usuario
    @GetMapping
    public ResponseEntity<LoginDto> obterUsuario(@Valid @RequestBody UserModel dados) {
        
    }

    //atualizar dados usuario
    @PutMapping
    public ResponseEntity<MensagemDtos> atualizarUsuario(@Valid @RequestBody UserModel dados) {

        boolean sucesso = servico.(dados);
        MensagemDtos resposta = new MensagemDtos();
        
        if (sucesso) {
            resposta.setMensagemdto("Usuario atualizado!");
        } else {
            resposta.setMensagemdto("Falha ao atualizar o usuario!");
        }
        return ResponseEntity.ok(resposta);
    }

}
