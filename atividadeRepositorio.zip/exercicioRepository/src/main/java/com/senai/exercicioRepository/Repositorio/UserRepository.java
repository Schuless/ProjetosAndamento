package com.senai.exercicioRepository.Repositorio;

import com.senai.exercicioRepository.DTOs.LoginDto;
import com.senai.exercicioRepository.Model.UserModel;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserModel, Long> {

    public Optional<UserModel> findByLogin(LoginDto login);
    
}
