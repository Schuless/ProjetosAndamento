package com.senai.exercicioRepository;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioRepositoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioRepositoryApplication.class, args);
	}

}
