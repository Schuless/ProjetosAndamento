package com.senai.exercicioRepository.DTOs;

public class MensagemDtos {
    
    private String mensagemDto;

    public MensagemDtos() {
    }

    public String getMensagemdto() {
        return mensagemDto;
    }

    public void setMensagemdto(String mensagemdto) {
        this.mensagemDto = mensagemdto;
    }
    
    
    
}
