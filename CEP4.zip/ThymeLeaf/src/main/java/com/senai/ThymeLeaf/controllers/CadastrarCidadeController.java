package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.CidadeDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping()
public class CadastrarCidadeController {
    
    @GetMapping("/cadastrarcidade")
    public String exibirListaCidades(Model model){
        
        CidadeDto cidadeDto = new CidadeDto();
        
        model.addAttribute("cidadeDto", cidadeDto);
        
        return "cadastrarcidade";
    }
    
    
}
