package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.EstadoDto;
import com.senai.ThymeLeaf.services.EstadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/estado")
public class EstadoController {
    
    @Autowired
    private EstadoService estadoService;  
    
    @PostMapping()
    public String cadastrarContato(@ModelAttribute("estado") EstadoDto estado){
        
        boolean sucesso = estadoService.cadastrarEstado(estado);
        
        if (sucesso){
            return "redirect:listaestados";
        }

        return "redirect:cadastrarestados?erro";        
    }
}
