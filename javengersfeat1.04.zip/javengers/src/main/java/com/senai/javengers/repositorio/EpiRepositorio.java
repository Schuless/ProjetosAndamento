package com.senai.javengers.repositorio;

public interface EpiRepositorio {
    
}
