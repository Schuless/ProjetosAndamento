package com.senai.javengers.controller;

public class ColaboradorViewController {
    
}
