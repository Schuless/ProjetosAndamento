package com.senai.javengers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavengersApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavengersApplication.class, args);
	}

}
