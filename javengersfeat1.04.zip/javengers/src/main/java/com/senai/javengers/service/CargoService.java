package com.senai.javengers.service;

import com.senai.javengers.dto.CargoDto;

public class CargoService {

    public CargoDto obterCargo(Long id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
