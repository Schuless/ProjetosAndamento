package com.senai.javengers.service;

public class ColaboradorService {
    
}
