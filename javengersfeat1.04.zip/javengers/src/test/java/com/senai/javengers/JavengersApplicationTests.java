package com.senai.javengers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavengersApplicationTests {

	@Test
	void contextLoads() {
	}

}
