package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.EstadoDto;
import com.senai.ThymeLeaf.services.EstadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@RequestMapping("/estado")
public class EstadoController {

    @Autowired
    private EstadoService estadoService;

    @GetMapping("/cadastrar")
    public String exibirCadastroEstado(Model model) {
        EstadoDto estadoDto = new EstadoDto();
        model.addAttribute("estadoDto", estadoDto);
        return "cadastrarestado";
    }

    @PostMapping()
    public String cadastrarEstado(Model model, @ModelAttribute("estadoDto") EstadoDto estado) {
            
        System.out.println("Estado = " + estado.getNome());    
        boolean sucesso = estadoService.cadastrarEstado(estado);
        if (sucesso) {
            return "redirect:/listaestados";
        }
        return "redirect:/estado/cadastrar?erro";
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String>  excluirEstado(@PathVariable Long id){
    
        boolean sucesso = estadoService.excluirEstado(id);
        
        if (sucesso){
            return ResponseEntity.ok("Estado excluído com sucesso.");
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao excluir Estado.");
        
    }
}
