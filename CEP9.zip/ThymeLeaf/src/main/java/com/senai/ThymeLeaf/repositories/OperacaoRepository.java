package com.senai.ThymeLeaf.repositories;

public interface OperacaoRepository {
    
}
