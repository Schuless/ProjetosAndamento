package com.senai.ThymeLeaf.repositories;

import com.senai.ThymeLeaf.models.CidadeModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CidadeRepository extends JpaRepository<CidadeModel,Long> {
    
    //- Método que realiza o select no banco de dados filtrando no where o email do usuário
    //public Optional<CidadeModel> findByEmail(String email);
    
}