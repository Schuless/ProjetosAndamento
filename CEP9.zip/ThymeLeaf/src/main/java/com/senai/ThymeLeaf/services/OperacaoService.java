package com.senai.ThymeLeaf.services;

import com.senai.ThymeLeaf.models.OperacaoModel;
import com.senai.ThymeLeaf.repositories.OperacaoRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OperacaoService {
    
    @Autowired
    OperacaoRepository operacaoRepositorio;
    
    public List<OperacaoModel> obterListaEstados(){
        
        List<OperacaoModel> lista = operacaoRepositorio.findAll();
        
        return lista;
        
    }
    
}
