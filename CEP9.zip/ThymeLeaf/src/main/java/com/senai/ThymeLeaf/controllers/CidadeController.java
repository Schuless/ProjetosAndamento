package com.senai.ThymeLeaf.controllers;

import com.senai.ThymeLeaf.dtos.CidadeDto;
import com.senai.ThymeLeaf.services.CidadesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/cidade")
public class CidadeController {

    @Autowired
    private CidadesService cidadeService;

    @GetMapping("/cadastrar")
    public String exibirCadastroEstado(Model model) {
        CidadeDto cidadeDto = new CidadeDto();
        model.addAttribute("cidadeDto", cidadeDto);
        return "cadastrarcidade";
    }

    @PostMapping()
    public String cadastrarCidade(Model model, @ModelAttribute("cidadeDto") CidadeDto cidade) {
            
        System.out.println("Cidade = " + cidade.getNome());    
        boolean sucesso = cidadeService.cadastrarCidade(cidade);
        if (sucesso) {
            return "redirect:/listacidades";
        }
        return "redirect:/cidade/cadastrar?erro";
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String>  excluirCidade(@PathVariable Long id){
    
        boolean sucesso = cidadeService.excluirCidade(id);
        
        if (sucesso){
            return ResponseEntity.ok("Cidade excluída com sucesso.");
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao excluir Cidade.");
        
    }
}

