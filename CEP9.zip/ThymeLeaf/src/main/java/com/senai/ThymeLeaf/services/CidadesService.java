package com.senai.ThymeLeaf.services;

import com.senai.ThymeLeaf.dtos.CidadeDto;
import com.senai.ThymeLeaf.models.CidadeModel;
import com.senai.ThymeLeaf.models.ContatoModel;
import com.senai.ThymeLeaf.models.EstadoModel;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.senai.ThymeLeaf.repositories.CidadeRepository;
import java.util.Optional;

@Service
public class CidadesService {

    @Autowired
    CidadeRepository repositorio;

    public boolean cadastrarCidade(CidadeDto dados) {

        CidadeModel cidade = new CidadeModel();
        cidade.setNome(dados.getNome());
        EstadoModel estado = new EstadoModel();
        cidade.setEstadoModel(estado);

        repositorio.save(cidade);

        return true;

    }

    public List<CidadeModel> obterListaCidades() {

        List<CidadeModel> lista = repositorio.findAll();

        return lista;

    }

    public boolean excluirCidade(Long id) {
        System.out.println("id:" + id);

        Optional<CidadeModel> optionalCidade = repositorio.findById(id);

        if (!optionalCidade.isPresent()) 
            return false;
        

        repositorio.delete(optionalCidade.get());

        return true;
    }
}
